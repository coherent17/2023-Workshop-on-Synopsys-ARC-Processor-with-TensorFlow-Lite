#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "embARC.h"
#include "embARC_debug.h"
#include "board_config.h"
#include "arc_timer.h"
#include "hardware_config.h"

#include "hx_drv_iic_m.h"
#include "hx_drv_iomux.h"
#include "SC16IS750_Bluepacket.h"


int16_t TestUART(uint8_t interface);


int main(void)
{
	printf("into %s-%d\r\n", __func__, __LINE__);
	HX_GPIOSetup();
	IRQSetup();
	UartInit(SC16IS750_PROTOCOL_SPI);
	InitGPIOSetup(SC16IS750_PROTOCOL_SPI);
	TestUART(SC16IS750_PROTOCOL_SPI);
	//StartTestCMD(SC16IS750_PROTOCOL_SPI);
	//TestGPIO();		

	return 0;
}